SELECT *
FROM [dbo].[Sales_LOAD]
WHERE Retailer = 'Sugar Cube'
AND SalesMonth = '2020-09-01';
